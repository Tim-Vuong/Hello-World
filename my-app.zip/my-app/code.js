var list= [];
var index;
onEvent("startButton", "click", function( ) {
   updateLists();
});

onEvent("createButton", "click", function( ) {
  setScreen("newListScreen");
});
onEvent("saveButton", "click", function( ) {
  var addList= {};
  addList.title= getText("titleInput");
  addList.thing1=getText("thing1Input");
  addList.thing2=getText("thing2Input");
  addList.thing3=getText("thing3Input");
  addList.thing4=getText("thing4Input");
  addList.thing5=getText("thing5Input");
  if (getText("0ListText")=="Empty"){
      setText("0ListText", getText("titleInput"));
      createRecord("myList", addList, function() {
    });
    create();
  }
  else if (getText("1ListText")=="Empty") {
    setText("1ListText", getText("titleInput"));
      createRecord("myList", addList, function() {
    });
    create();
  }
  else if (getText("2ListText")=="Empty"){
    setText("2ListText", getText("titleInput"));
      createRecord("myList", addList, function() {
    });
    create();
  }
  else if (getText("3ListText")=="Empty"){
    setText("3ListText", getText("titleInput"));
      createRecord("myList", addList, function() {
    });
    create();
  }
  else if (getText("4ListText")=="Empty"){
    setText("4ListText", getText("titleInput"));
      createRecord("myList", addList, function() {
    });
    create();
  }
  else if (getText ("5ListText")=="Empty"){
    setText("5ListText", getText("titleInput"));
      createRecord("myList", addList, function() {
    });
    create();
  }
  else {
    create();
    setScreen("tooManyListsScreen");
  }
  });
  
  onEvent("backToListsButton", "click", function( ) {
    setScreen ("yourListsScreen");
  });
  
onEvent("cancelButton", "click", function( ) {
  setScreen ("yourListsScreen");
});

onEvent("0ListText", "click", function( ) {
  readRecords("myList", {}, function(records) {
    list=records;
    index=0;
    setArea();
  });
});
onEvent("1ListText", "click", function( ) {
  readRecords("myList", {}, function(records) {
    list=records;
    index=1;
    setArea();
    });
});
onEvent("2ListText", "click", function( ) {
  readRecords("myList", {}, function(records) {
    list=records;
      index=2;
      setArea();
     });
});
onEvent("3ListText", "click", function( ) {
  readRecords("myList", {}, function(records) {
    list=records;
      index=3;
       setArea();
       });
});
onEvent("4ListText", "click", function( ) {
  readRecords("myList", {}, function(records) {
    list=records;
      index=4;
      setArea();
      });
});
onEvent("5ListText", "click", function( ) {
    readRecords("myList", {}, function(records) {
    list=records;
      index=5;
      setArea();
    });
});
onEvent("editButton", "click", function( ) {
  setText("editTitleInput", list[index].title);
  setText("edit1Input", list[index].thing1);
  setText("edit2Input", list[index].thing2);
  setText("edit3Input", list[index].thing3);
  setText("edit4Input", list[index].thing4);
  setText("edit5Input", list[index].thing5);
  setScreen("editScreen");
});

onEvent("backButton", "click", function( ) {
  setScreen("yourListsScreen");
});

onEvent("updateButton", "click", function( ) {
  var thingToUpdate = list[index];
  thingToUpdate.title = getText("editTitleInput");
  thingToUpdate.thing1 = getText("edit1Input");
  thingToUpdate.thing2 = getText("edit2Input");
  thingToUpdate.thing3 = getText("edit3Input");
  thingToUpdate.thing4 = getText("edit4Input");
  thingToUpdate.thing5 = getText("edit5Input");
  updateRecord("myList", thingToUpdate, function() {
  updateLists();
  });
});

onEvent("deleteButton", "click", function( ) {
  setScreen("deleteScreen");
});
onEvent("noButton", "click", function( ) {
  setScreen("editScreen");
});
onEvent("yesButton", "click", function( ) {
  var thingToDelete = list[index];
  deleteRecord("myList", thingToDelete, function() {
  updateLists();
  });
});
function create() {
  setText ("titleInput", "");
  setText("thing1Input", "");
  setText("thing2Input", "");
  setText("thing3Input", "");
  setText("thing4Input", "");
  setText("thing5Input", "");
  setScreen("yourListsScreen");
}
function setArea() {
  if (list[index]!=undefined) {
  setText("titleArea", list[index].title);
  setText("thingsArea", list[index].thing1 + "\n\n"+list[index].thing2 + "\n\n"+list[index].thing3 + "\n\n"+list[index].thing4 + "\n\n"+list[index].thing5);
  setScreen("listScreen");
  }
}
function updateLists() {
readRecords("myList", {}, function(records) {
      if (records[0]!= undefined) {
        setText("0ListText", records[0].title);
      }
      else {
        setText ("0ListText", "Empty");
      }
      if (records[1]!= undefined) {
        setText("1ListText", records[1].title);
         }
      else {
          setText ("1ListText", "Empty");
      }
      if (records[2]!= undefined) {
        setText("2ListText", records[2].title);
      }
      else {
          setText ("2ListText", "Empty");
      }
      if (records[3]!= undefined) {
        setText("3ListText", records[3].title);
      }
      else {
          setText ("3ListText", "Empty");
      }
      if (records[4]!= undefined) {
        setText("4ListText", records[4].title);
      }
      else {
          setText ("4ListText", "Empty");
      }
      if (records[5]!= undefined) {
        setText("5ListText", records[5].title);
      }
      else {
          setText ("5ListText", "Empty");
      }
          setScreen ("yourListsScreen");
  });
}
// code for memory game

onEvent("memoryButton", "click", function( ) {
  setScreen("memoryScreen");
});
onEvent("tryGameButton", "click", function( ) {
  setScreen("memoryScreen");
});
onEvent("beginMemoryButton", "click", function( ) {
  setScreen("gameScreen");
  updateCounter();
  hideElement ("gameSubmitButton");
  hideElement("clickText");
  hideElement ("gameNumberInput");
  hideElement("sorryText");
  hideElement("goodJobText");
});
onEvent("exitGameButton", "click", function( ) {
  rightCounter=0;
  wrongCounter=0;
  t=1000;
  updateCounter();
  updateLists();
});
onEvent("exitGameButton2", "click", function( ) {
  rightCounter=0;
  wrongCounter=0;
  t=1000;
  updateCounter();
  updateLists();
});
var a;
var b;
var c;
var d;
var e;
var rightCounter=0;
var wrongCounter=0;
var t= 1000;
onEvent("beginNumberButton", "click", function( ) {
  hideElement ("beginNumberButton");
  hideElement("goodJobText");
  hideElement ("sorryText");
  a= randomNumber(0,9);
  setText("number1Text",a);
  a=a*10000;
  setTimeout(function() {
    b= randomNumber(0,9);
    setText("number2Text", b);
    b= b*1000;
    setText("number1Text", " ");
        setTimeout(function() {
          c= randomNumber(0,9);
          setText("number3Text", c);
          c=c*100;
          setText("number2Text", " ");
              setTimeout(function() {
              d= randomNumber(0,9);
              setText("number4Text", d);
              d=d*10;
              setText("number3Text", " ");
                  setTimeout(function() {
                    e= randomNumber(0,9);
                    setText("number5Text", e);
                    setText("number4Text", " ");
                        setTimeout(function() {
                          setText("number5Text"," ");
                          showElement ("gameNumberInput");
                          showElement ("gameSubmitButton");
                          showElement("clickText");
                          
                        }, t);
                        
                  }, t);
                  
              }, t);
            
        }, t);
         
  }, t);
});
onEvent("gameSubmitButton", "click", function( ) {
  if (getText("gameNumberInput")== a+b+c+d+e){
    rightCounter++;
    updateCounter();
    t=t-100;
    showElement("goodJobText");
  }
  else {
    wrongCounter++;
    showElement ("sorryText");
    updateCounter();
  }
  setText("gameNumberInput", "");
  setText("beginNumberButton", "Again!");
  showElement("beginNumberButton");
  hideElement("gameSubmitButton");
  hideElement("clickText");
  hideElement("gameNumberInput");
});

onEvent("gameScreen", "keydown", function(event) {
    if(event.key == "Enter"){
  if (getText("gameNumberInput")== a+b+c+d+e){
    rightCounter++;
    updateCounter();
    t=t-100;
    showElement("goodJobText");
  }
  else {
    wrongCounter++;
    showElement("sorryText");
    updateCounter();
  }
  setText("gameNumberInput", "");
  setText("beginNumberButton", "Again!");
  showElement("beginNumberButton");
  hideElement("gameSubmitButton");
  hideElement("clickText");
  hideElement("gameNumberInput");
    }
});

function updateCounter() {
  setText ("rightCounter", rightCounter);
  setText ("wrongCounter",wrongCounter);
}
